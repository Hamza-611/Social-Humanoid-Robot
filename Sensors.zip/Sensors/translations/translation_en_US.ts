<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Tap me wherever you feel pain.</source>
            <comment>Text</comment>
            <translation type="unfinished">Tap me wherever you feel pain.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Tap me wherever you feel pain.</source>
            <comment>Text</comment>
            <translation type="obsolete">Tap me wherever you feel pain.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>My head</source>
            <comment>Text</comment>
            <translation type="unfinished">My head</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Tap me wherever you feel pain.</source>
            <comment>Text</comment>
            <translation type="obsolete">Tap me wherever you feel pain.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>right hand</source>
            <comment>Text</comment>
            <translation type="unfinished">right hand</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Tap me wherever you feel pain.</source>
            <comment>Text</comment>
            <translation type="obsolete">Tap me wherever you feel pain.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>left hand</source>
            <comment>Text</comment>
            <translation type="unfinished">left hand</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Tap me wherever you feel pain.</source>
            <comment>Text</comment>
            <translation type="obsolete">Tap me wherever you feel pain.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>My Foot</source>
            <comment>Text</comment>
            <translation type="unfinished">My Foot</translation>
        </message>
    </context>
</TS>
